# Serverless Devs Core Community Code of Conduct

Serverless Devs Core follows the [CNCF Code of Conduct](https://github.com/cncf/foundation/blob/master/code-of-conduct.md).

In cases of abusive, harassing, or any unacceptable behaviors, please don't hesitate to contact the project team at service@serverlessfans.com.
