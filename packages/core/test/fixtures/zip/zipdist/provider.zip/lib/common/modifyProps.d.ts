declare function modifyProps(service: string, options: object): Promise<void>;
export default modifyProps;
