declare function validateProps(input: any): Promise<any[]>;
export default validateProps;
