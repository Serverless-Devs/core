interface ReportOptions {
    type: 'error' | 'component';
    context?: string;
    params?: object;
}
export default function report(message: any, options: ReportOptions): Promise<any>;
export {};
