export declare const providerArray: string[];
export declare const providerObject: any;
export declare const providerCollection: any;
export declare const checkProviderList: any[];
export declare function getInputData(program: any): any;
