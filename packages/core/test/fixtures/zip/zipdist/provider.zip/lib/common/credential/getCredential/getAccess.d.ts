export default function getAccess(provider: string, accessAlias?: string): {};
