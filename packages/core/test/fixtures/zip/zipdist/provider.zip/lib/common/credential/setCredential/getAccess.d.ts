export default function getAccess(provider?: string): {};
