import { DownloadOptions as MyDownloadOptions } from 'download';
interface HintOptions {
    loading?: string;
    success?: string;
    error?: string;
}
interface RequestOptions {
    method?: string;
    body?: object;
    params?: object;
    hint?: HintOptions;
    [key: string]: any;
}
export declare type DownloadOptions = MyDownloadOptions;
export declare function request(url: string, options?: RequestOptions): Promise<any>;
export declare function downloadRequest(url: string, dest: string, options?: MyDownloadOptions): Promise<void>;
export {};
