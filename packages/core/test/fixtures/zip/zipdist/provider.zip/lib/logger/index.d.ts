declare type LogColor = 'black' | 'red' | 'green' | 'yellow' | 'blue' | 'magenta' | 'cyan' | 'white' | 'whiteBright' | 'gray';
export interface ILogger {
    log: (message: any, color?: LogColor) => any;
    info: (...data: any[]) => any;
    debug: (...data: any[]) => any;
    warn: (...data: any[]) => any;
    error: (...data: any[]) => any;
}
export declare const logger: (name: string) => ILogger;
export declare class Logger {
    context: string;
    constructor(context?: string);
    static log(message: any, color?: LogColor): boolean;
    static debug(name: string, data: any): void;
    static info(name: string, data: any): void;
    static warn(name: string, data: any): void;
    static error(name: string, data: any): void;
    log(message: any, color?: LogColor): boolean;
    debug(data: any): void;
    info(data: any): void;
    warn(data: any): void;
    error(data: any): void;
}
export {};
