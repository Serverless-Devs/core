export declare const SERVERLESS_API = "https://tool.serverlessfans.com/api";
export interface IRemoteComponentParams {
    name: string;
    provider: string;
    type?: any;
}
/**
 *
 * @description 获取组件版本
 * @param params IRemoteComponentParams
 */
export declare const getComponentVersion: (params: IRemoteComponentParams) => Promise<any>;
/**
 * @description 获取下载链接
 * @param params IRemoteComponentParams
 */
export declare function getComponentDownloadUrl(params: IRemoteComponentParams): Promise<any>;
export declare function execComponentDownload(url: string, tempDir: string): Promise<void>;
