import { Section } from 'command-line-usage';
declare function help(sections: Section | Section[]): void;
export default help;
