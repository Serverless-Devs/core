/**
 * @description 用于存放工具函数
 */
import { uid } from 'uid/secure';
export declare const merge: any;
export declare const isUndefined: (obj: any) => obj is undefined;
export declare const isObject: (fn: any) => fn is object;
export declare const isPlainObject: (fn: any) => fn is object;
export declare const isFunction: (fn: any) => boolean;
export declare const isString: (fn: any) => fn is string;
export declare const isConstructor: (fn: any) => boolean;
export declare const isNil: (obj: any) => obj is null;
export declare const isEmpty: (array: any) => boolean;
export declare const isSymbol: (fn: any) => fn is symbol;
export declare const omitObject: (object: any, callback: any) => {
    [key: string]: any;
};
export declare const map: (object: any, callback: any) => {
    [key: string]: any;
}[];
export declare const uuid: typeof uid;
export declare function readJsonFile(filePath: string): {};
export declare function writeJsonFile(filePath: string, data: any): void;
export declare function sleep(timer: number): Promise<unknown>;
