import { Registry } from './service';
declare function loadComponent(source: string, registry?: Registry): Promise<any>;
export declare const load: typeof loadComponent;
export default loadComponent;
