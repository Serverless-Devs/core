import { IInputs, IV1Inputs } from '../interface';
declare function commandParse(inputs: IInputs | IV1Inputs, opts?: object): {
    rawData?: string;
    data: object;
};
export default commandParse;
