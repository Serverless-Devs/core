interface ProfileParame {
    data?: any;
    configKey?: string;
    read?: boolean;
    filePath?: string;
}
interface Profile {
    [key: string]: any;
}
export declare function setConfig(key: string, value: any): void;
export declare function getConfig(key: string): any;
export declare function handlerProfileFile(parame: ProfileParame): Promise<Profile>;
export {};
