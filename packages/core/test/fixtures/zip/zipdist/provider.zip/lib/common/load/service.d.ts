import { IComponentParams } from '../../interface';
export interface IComponentPath {
    componentVersion: string;
    applicationPath?: string;
    componentPath: string;
    lockPath: string;
}
export declare type Registry = 'https://tool.serverlessfans.com/api' | 'https://api.github.com/repos';
export declare enum RegistryEnum {
    github = "https://api.github.com/repos",
    serverless = "https://tool.serverlessfans.com/api"
}
/**
 * @description 获取组件路径
 * @param name
 * @param provider
 * @param componentPathRoot 组件serverlessfans根目录
 */
export declare const generateComponentPath: ({ name, provider, version }: IComponentParams, componentPathRoot: string) => Promise<IComponentPath>;
export declare const installDependency: (name: string, { componentPath, componentVersion, lockPath }: IComponentPath) => Promise<void>;
export declare const installAppDependency: (applicationPath: string) => Promise<void>;
export declare const downloadComponent: (outputDir: string, { name, provider }: IComponentParams) => Promise<void>;
export declare const buildComponentInstance: (componentPath: string) => Promise<any>;
export declare const getGithubReleases: (user: string, name: string) => Promise<any>;
export declare const getGithubReleasesLatest: (user: string, name: string) => Promise<any>;
