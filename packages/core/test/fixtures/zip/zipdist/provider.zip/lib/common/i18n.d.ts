declare const i18n: any;
export default i18n;
