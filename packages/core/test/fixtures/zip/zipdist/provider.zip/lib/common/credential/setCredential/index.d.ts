declare function setCredential(provider?: string): Promise<any>;
export default setCredential;
