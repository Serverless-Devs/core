import { Ora } from 'ora';
export default function spinner(message: any): Ora;
