export { default as getCredential } from './getCredential';
export { default as setCredential } from './setCredential';
