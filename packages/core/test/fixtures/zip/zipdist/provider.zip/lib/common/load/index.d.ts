export { default as loadComponent, load } from './loadComponent';
export { default as loadApplication } from './loadApplication';
