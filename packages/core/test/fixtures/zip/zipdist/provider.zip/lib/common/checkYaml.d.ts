declare function readPublish(input: any): Promise<any[]>;
export default readPublish;
