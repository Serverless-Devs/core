export declare function getState(id: any): Promise<{}>;
export declare function setState(id: any, state: any): Promise<any>;
