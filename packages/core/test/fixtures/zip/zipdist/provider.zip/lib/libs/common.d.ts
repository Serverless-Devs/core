/**
 * @description 业务通用代码
 */
export declare const S_ROOT_HOME: any;
export declare const S_CURRENT_HOME: any;
export declare const S_CURRENT: any;
export declare const S_ROOT_HOME_ACCESS: any;
export declare const S_ROOT_HOME_COMPONENT: any;
