declare function addAccess(provider?: string): Promise<any>;
export default addAccess;
