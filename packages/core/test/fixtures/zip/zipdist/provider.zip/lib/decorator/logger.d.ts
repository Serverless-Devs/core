export declare const Logger: (context: string) => (target: any, key: string) => void;
