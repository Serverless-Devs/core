declare function getCredential(provider: string, accessAlias?: string): Promise<any>;
export default getCredential;
