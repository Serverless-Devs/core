interface Options {
    codeUri: string;
    exclude?: Array<string>;
    include?: Array<string>;
    outputFileName?: string;
    outputFilePath?: string;
}
declare function zip(options: Options): Promise<unknown>;
export default zip;
