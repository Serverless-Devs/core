import { Registry } from './service';
declare function loadApplication(source: string, registry?: Registry, target?: string): Promise<any>;
export default loadApplication;
